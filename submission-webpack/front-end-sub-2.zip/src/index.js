import "./script/components/index.js";

import home from "./script/view/home.js";
import "./styles/style.css";

document.addEventListener("DOMContentLoaded", () => {
  home();
});
